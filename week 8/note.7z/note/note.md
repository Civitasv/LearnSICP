# Note

- All evals are done in some environment (eval exp env)
- Create a new environment when you invoke a procedure.
